package com.traveloutdoor.mobile_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
